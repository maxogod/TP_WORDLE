# TP_WORDLE

Wordle on python.
( Run TP2_UNO.py to run the game )
